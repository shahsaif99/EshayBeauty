import React from "react"

export default function Main(){
   return (
     <img src="./images/background.jpg"/>
   )
}