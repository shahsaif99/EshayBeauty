import React from "react"
import 'bootstrap/dist/css/bootstrap.min.css';




export default function Header(){
    
    
    return(
        <div className="main">
            <nav className="navbar navbar-expand-lg ">
       <div className="container-fluid mt-4 ">
    <a className="navbar-brand" href="#">Website Logo</a>
    <button style={{'border':'none'}} className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <i class="fa fa-bars" style={{'color':'#fff', 'font-size':'28px'}}></i>
    </button>
    
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      <ul className="navbar-nav ms-auto">
        <li className="nav-item">
          <a className="nav-link active" aria-current="page" href="#"> <i className="fa fa-instagram ic-logo" aria-hidden="true"></i></a>
        </li>
        <li className="nav-item">
          <a className="nav-link" href="#"><i className="fa fa-facebook-square ic-logo" aria-hidden="true"></i></a>
        </li>
        
      </ul>
    </div>
    <ul className="navbar-nav ms-auto">

        <li className="nav-item">
          <a className="nav-link" href="#"><i className="fa fa-shopping-bag logo-cart" aria-hidden="true"></i></a>
        </li>
    </ul>
  </div>
</nav>

       <div className="main-text">Meet our new<br/> limited collection</div> 
       <div className="sub-text">Available now</div>
        </div>
    )
}

// style={{width:`34px`, height:`26px` }}
// aadil code
    //     <div className="row">
    //     <div className="col-sm-12 main">
    //     <nav className="navbar navbar-expand-md ">
    //         <div className="container-fluid m-4">
    //             <a className="navbar-brand" href="#"><span>Mariana</span></a>
    //                 <ul className="navbar-nav mr-auto">
    //                     <i className="fa fa-instagram ic-logo fs-2" style={{'margin-right': '15px'}}></i>
    //                     <i className="fa fa-facebook-square ic-logo fs-2" style={{'margin-right': '20px'}}></i>
    //                     <i className="fa fa-shopping-bag logo-cart fs-1"></i>
    //                 </ul>
    //         </div>
    //     </nav>
    //         <div className="main-text">Meet our new<br /> limited collection</div>
    //         <div className="sub-text">Available now</div>
    //     </div>
    // </div>



    // mycode
        // <nav className=" container-fluid header" >
        //     {/* <img src="./images/background.jpg" className="bg-img"/> */}
        // <div className="row">

        //     <h1 className="col-10 logo"> Website Logo</h1>
        //     <div className="col-2" >
        //         <ul>
                    

        //     <i className="fa fa-instagram ic-logo" aria-hidden="true"></i>
        //     <i class="fa fa-facebook-square ic-logo" aria-hidden="true"></i>
        //     <i class="fa fa-shopping-bag logo-cart" aria-hidden="true"></i>

        //         </ul>
            
        //     </div>
        //     </div>

        // </nav>
        // my code
//         <div className="main">
//             <nav class="navbar navbar-expand-lg ">
//        <div class="container-fluid mt-4 ">
//     <a class="navbar-brand" href="#">Website Logo</a>
//     <button class="navbar-toggler tog-btn" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
//       <span class="navbar-toggler-icon tog-btn"></span>
//     </button>
//     <div class="collapse navbar-collapse" id="navbarNav">
//       <ul class="navbar-nav ms-auto">
//         <li class="nav-item">
//           <a class="nav-link active" aria-current="page" href="#"> <i className="fa fa-instagram ic-logo" aria-hidden="true"></i></a>
//         </li>
//         <li class="nav-item">
//           <a class="nav-link" href="#"><i class="fa fa-facebook-square ic-logo" aria-hidden="true"></i></a>
//         </li>
        
//       </ul>
//     </div>
//     <ul className="navbar-nav ms-auto">

//         <li class="nav-item">
//           <a class="nav-link" href="#"><i class="fa fa-shopping-bag logo-cart" aria-hidden="true"></i></a>
//         </li>
//     </ul>
//   </div>
// </nav>

//        <div className="main-text">Meet our new<br/> limited collection</div> 
//        <div className="sub-text">Available now</div>
//         </div>