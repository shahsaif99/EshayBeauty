import React from "react"
import Header from "./Home/Header"
import Card from "./Home/Card"

export default function App(){
    return(
        <div>

        <Header/>
        <Card/>
        </div>
    )
}