import React from "react"
import Header from "./Home/Header"
import Main from "./Home/Main"

export default function App(){
    return(
        <div>

        <Header/>
        {/* <Main/> */}
        </div>
    )
}